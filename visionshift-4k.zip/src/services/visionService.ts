import { GoogleGenAI } from "@google/genai";

let genAI: GoogleGenAI | null = null;

export const getGenAI = () => {
  if (!genAI) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined");
    }
    genAI = new GoogleGenAI({ apiKey });
  }
  return genAI;
};

export async function convertMobileToDesktop(base64Image: string, mimeType: string, userPrompt?: string) {
  const ai = getGenAI();
  
  // Base prompt for extension
  let prompt = `This is a mobile portrait photo. I need you to convert it into a widescreen 16:9 desktop wallpaper. 
  Keep all the main subjects, style, and colors exactly as they are. 
  Generatively fill the left and right sides to create a seamless landscape version of the scene. 
  Make it look natural, photorealistic, and cinematic.`;

  if (userPrompt) {
    prompt += `\n\nAdditional creative direction from the user: ${userPrompt}. 
    Incorporate these elements or style into the expanded areas while keeping the original center content consistent.`;
  }

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image,
            mimeType: mimeType,
          },
        },
        {
          text: prompt,
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9",
      },
    },
  });

  const part = response.candidates[0].content.parts.find(p => p.inlineData);
  if (!part || !part.inlineData) {
    throw new Error("No image part found in response");
  }

  return `data:image/png;base64,${part.inlineData.data}`;
}
