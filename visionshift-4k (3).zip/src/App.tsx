/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Image as ImageIcon, 
  Monitor, 
  Download, 
  Loader2, 
  Smartphone, 
  ArrowRight,
  Sparkles,
  RefreshCw,
  X,
  Menu,
  Moon,
  Sun,
  Palette,
  History,
  Info,
  ChevronDown,
  LayoutGrid
} from 'lucide-react';
import { convertMobileToDesktop, refineWallpaper, type Resolution, type AspectRatio } from './services/visionService';
import { cn } from './lib/utils';
import JSZip from 'jszip';

type Theme = 'dark' | 'light' | 'cream';

interface GenerationRecord {
  id: string;
  original: string;
  converted: string;
  aspectRatio: AspectRatio;
  timestamp: number;
}

export default function App() {
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('theme') as Theme) || 'cream');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  
  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    });

    window.addEventListener('appinstalled', () => {
      setIsInstallable(false);
      setDeferredPrompt(null);
    });
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstallable(false);
    }
    setDeferredPrompt(null);
  };
  const [convertedImage, setConvertedImage] = useState<string | null>(null);
  const [userPrompt, setUserPrompt] = useState("");
  const [postPrompt, setPostPrompt] = useState("");
  const [resolution, setResolution] = useState<Resolution>('4K');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [history, setHistory] = useState<GenerationRecord[]>(() => {
    const saved = localStorage.getItem('vision_history');
    return saved ? JSON.parse(saved) : [];
  });

  const fileInputRef = useRef<HTMLInputElement>(null);
  const converterRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    document.body.className = `theme-${theme}`;
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('vision_history', JSON.stringify(history.slice(0, 10)));
  }, [history]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError("Please upload an image file.");
      return;
    }
    setError(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      setOriginalImage(e.target?.result as string);
      setConvertedImage(null);
      setPostPrompt("");
      // Scroll to converter if not in view
      converterRef.current?.scrollIntoView({ behavior: 'smooth' });
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleConvert = async () => {
    if (!originalImage) return;
    setIsProcessing(true);
    setError(null);
    try {
      const [typePart, dataPart] = originalImage.split(',');
      const mimeType = typePart.split(':')[1].split(';')[0];
      const result = await convertMobileToDesktop(dataPart, mimeType, userPrompt, resolution, aspectRatio);
      setConvertedImage(result);
      
      // Add to history
      const newRecord: GenerationRecord = {
        id: crypto.randomUUID(),
        original: originalImage,
        converted: result,
        aspectRatio: aspectRatio,
        timestamp: Date.now()
      };
      setHistory(prev => [newRecord, ...prev]);
    } catch (err: any) {
      handleError(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRefine = async () => {
    if (!convertedImage || !postPrompt) return;
    setIsProcessing(true);
    setError(null);
    try {
      const [typePart, dataPart] = convertedImage.split(',');
      const mimeType = typePart.split(':')[1].split(';')[0];
      const result = await refineWallpaper(dataPart, mimeType, postPrompt, aspectRatio);
      setConvertedImage(result);
      setPostPrompt("");
    } catch (err: any) {
      handleError(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleError = (err: any) => {
    let message = err.message || "An error occurred.";
    if (message.includes("403") || message.includes("PERMISSION_DENIED")) {
      message = "Permission Denied: Model restricted. Using fallbacks.";
    } else if (message.includes("429") || message.includes("RESOURCE_EXHAUSTED")) {
      message = "Quota Exceeded: Too many requests.";
    }
    setError(message);
  };

  const reset = () => {
    setOriginalImage(null);
    setConvertedImage(null);
    setError(null);
  };

  const downloadImage = (url: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = 'visionshift-wallpaper.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadProjectSource = async () => {
    setIsProcessing(true);
    const zip = new JSZip();
    const files = [
      'src/App.tsx', 
      'src/main.tsx', 
      'src/index.css', 
      'src/services/visionService.ts', 
      'src/lib/utils.ts', 
      'package.json', 
      'vite.config.ts', 
      'index.html', 
      'metadata.json', 
      'tsconfig.json',
      'public/manifest.json',
      'public/sw.js'
    ];
    
    for (const file of files) {
      try {
        const resp = await fetch(`/${file}`);
        if (resp.ok) {
          const text = await resp.text();
          zip.file(file, text);
        }
      } catch (e) {
        console.error(`Failed to fetch ${file}`, e);
      }
    }
    
    try {
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'visionshift-4k-source.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (e) {
      setError("Failed to generate project ZIP.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Navigation & Sidebar */}
      <nav className="fixed top-0 left-0 right-0 h-20 z-50 flex items-center justify-between px-8 border-b border-[var(--border-color)] bg-[var(--bg-primary)]/80 backdrop-blur-xl">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsMenuOpen(true)}
            className="p-2 rounded-xl hover:bg-[var(--card-bg)] transition-colors"
          >
            <Menu className="w-6 h-6" />
          </button>
          <div className="flex flex-col">
            <span className="font-black text-xl tracking-tighter">VISIONSHIFT</span>
            <span className="text-[10px] text-[var(--text-secondary)] tracking-widest font-bold -mt-1 ml-0.5 uppercase">v2.0 Beta</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {isInstallable ? (
            <button 
              onClick={handleInstallClick}
              className="flex items-center gap-2 px-4 py-2 bg-[var(--accent)] text-white rounded-xl text-xs font-bold hover:scale-105 transition-all shadow-lg shadow-[var(--accent)]/20"
            >
              <Download className="w-4 h-4" /> Install App
            </button>
          ) : (
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="px-3 py-2 border border-[var(--border-color)] text-[var(--text-secondary)] rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-[var(--card-bg)] transition-colors"
            >
              Install Info
            </button>
          )}
          <ThemeToggle theme={theme} setTheme={setTheme} />
        </div>
      </nav>

      {/* Sidebar Drawer */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              className="fixed top-0 left-0 bottom-0 w-80 bg-[var(--bg-primary)] border-r border-[var(--border-color)] z-[70] p-8"
            >
              <div className="flex items-center justify-between mb-12">
                <span className="font-bold text-lg">System Specs</span>
                <button onClick={() => setIsMenuOpen(false)} className="p-2 hover:bg-[var(--card-bg)] rounded-lg">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-8">
                <MenuSection title="Model" icon={<Info className="w-4 h-4" />}>
                  <div className="text-sm font-mono opacity-60">Gemini 2.5 Flash Image</div>
                </MenuSection>
                
                <MenuSection title="Installation Guide" icon={<Download className="w-4 h-4" />}>
                  <div className="space-y-3 text-xs opacity-70 leading-relaxed">
                    <p>1. Open this app in a <strong>new tab</strong> (use the icon in the top right of the AI Studio preview).</p>
                    <p>2. Look for the <strong>"Install App"</strong> button in the navigation bar.</p>
                    <p>3. On mobile, use <strong>"Add to Home Screen"</strong> from your browser menu.</p>
                    <div className="pt-2">
                       <button 
                         onClick={downloadProjectSource}
                         className="flex items-center gap-2 px-3 py-2 bg-[var(--card-bg)] border border-[var(--border-color)] rounded-lg hover:bg-[var(--accent)] hover:text-white transition-all w-full justify-center font-bold"
                       >
                         <Download className="w-3 h-3" /> Download Source (ZIP)
                       </button>
                    </div>
                    <div className="pt-2">
                       <p className="opacity-40 italic font-mono uppercase text-[9px]">PWA Status: Ready for install</p>
                    </div>
                  </div>
                </MenuSection>

                <MenuSection title="Toolkit" icon={<LayoutGrid className="w-4 h-4" />}>
                  <ul className="space-y-4 text-sm opacity-70">
                    <li className="flex items-center gap-2"><Smartphone className="w-4 h-4" /> 4K Expansion</li>
                    <li className="flex items-center gap-2"><RefreshCw className="w-4 h-4" /> Iterative Refinement</li>
                    <li className="flex items-center gap-2"><Monitor className="w-4 h-4" /> Multi-Res (8K/16K)</li>
                    <li className="flex items-center gap-2"><Sparkles className="w-4 h-4" /> Cinematic Fill</li>
                  </ul>
                </MenuSection>

                <div className="pt-8 border-t border-[var(--border-color)]">
                    <p className="text-[10px] uppercase tracking-widest opacity-30 font-bold">Cloud Instance</p>
                    <p className="text-xs font-mono opacity-50 mt-1 truncate">{process.env.APP_URL}</p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <main className="pt-24 pb-12">
        {/* Upper Middle: Recent Generations */}
        <section className="max-w-7xl mx-auto px-6 mb-24">
          <div className="flex items-center gap-3 mb-8">
            <History className="w-5 h-5 text-[var(--accent)]" />
            <h2 className="text-sm font-bold uppercase tracking-[0.2em] opacity-40">Recent Visuals</h2>
          </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {history.length > 0 ? (
              history.map((record) => (
                <motion.div 
                  key={record.id}
                  layoutId={record.id}
                  className={cn(
                    "group relative rounded-2xl overflow-hidden border border-[var(--border-color)] bg-[var(--card-bg)] shadow-sm hover:shadow-xl transition-all",
                    record.aspectRatio === '16:9' ? "aspect-[16/9]" : 
                    record.aspectRatio === '21:9' ? "aspect-[21/9]" : "aspect-[32/9]"
                  )}
                >
                  <img src={record.converted} alt="History" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-6 text-center">
                    <div className="flex gap-2">
                       <button onClick={() => downloadImage(record.converted)} className="p-3 bg-white text-black rounded-full hover:scale-110 active:scale-95 transition-transform">
                        <Download className="w-4 h-4" />
                       </button>
                       <button onClick={() => { setConvertedImage(record.converted); setOriginalImage(record.original); setAspectRatio(record.aspectRatio); converterRef.current?.scrollIntoView({behavior: 'smooth'}) }} className="p-3 bg-white/20 text-white backdrop-blur-md rounded-full hover:scale-110 active:scale-95 transition-transform">
                        <RefreshCw className="w-4 h-4" />
                       </button>
                    </div>
                    <div className="mt-4 flex flex-col items-center gap-1">
                      <span className="text-[10px] text-white font-bold opacity-80">{record.aspectRatio}</span>
                      <span className="text-[10px] text-white/50 font-mono">{new Date(record.timestamp).toLocaleTimeString()}</span>
                    </div>
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="col-span-full h-40 flex flex-col items-center justify-center border-2 border-dashed border-[var(--border-color)] rounded-3xl opacity-30">
                <ImageIcon className="w-8 h-8 mb-2" />
                <p className="text-sm">Your generation history will appear here</p>
              </div>
            )}
          </div>
        </section>

        {/* Scroll down to upload */}
        <div className="flex flex-col items-center mb-12 animate-bounce opacity-20">
          <p className="text-xs uppercase tracking-widest font-bold mb-2">Scroll to Create</p>
          <ChevronDown className="w-6 h-6" />
        </div>

        {/* Main Converter Tool */}
        <section ref={converterRef} className="max-w-7xl mx-auto px-6 py-24 border-t border-[var(--border-color)]">
          <div className="text-center mb-16">
             <h2 className="text-5xl font-black tracking-tight mb-4">Transformation Core</h2>
             <p className="opacity-50 max-w-xl mx-auto">Upload a portrait photo to begin the expansion process.</p>
          </div>

          {!originalImage ? (
             <motion.div 
               whileHover={{ scale: 1.01 }}
               onDragOver={(e) => e.preventDefault()}
               onDrop={handleDrop}
               className="group relative max-w-2xl mx-auto h-80 border-2 border-dashed border-[var(--border-color)] rounded-[2.5rem] bg-[var(--card-bg)] flex flex-col items-center justify-center cursor-pointer transition-all hover:bg-[var(--accent)]/5 hover:border-[var(--accent)]/50"
               onClick={() => fileInputRef.current?.click()}
             >
                <input ref={fileInputRef} type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
                <div className="w-16 h-16 rounded-full bg-[var(--bg-primary)] border border-[var(--border-color)] flex items-center justify-center mb-6 shadow-sm group-hover:scale-110 transition-transform">
                  <Upload className="w-6 h-6 opacity-40 group-hover:opacity-100 group-hover:text-[var(--accent)]" />
                </div>
                <h3 className="text-xl font-bold mb-1">Upload 4K Mobile Portrait</h3>
                <p className="text-xs opacity-40">Drag and drop or click to browse</p>
             </motion.div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
               {/* Previews */}
               <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
                  {/* Original Mobile Preview */}
                  <div className="lg:col-span-4">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-[10px] font-black uppercase tracking-widest opacity-40">Portrait Source</span>
                      <button onClick={reset} className="p-1.5 hover:bg-black/5 rounded-full"><X className="w-4 h-4" /></button>
                    </div>
                    <div className="aspect-[9/16] rounded-2xl overflow-hidden border border-[var(--border-color)] shadow-xl relative">
                      <img src={originalImage} alt="Portrait" className="w-full h-full object-cover" />
                      <div className="absolute top-4 left-4 p-2 bg-black/20 backdrop-blur-md rounded-lg"><Smartphone className="w-4 h-4 text-white" /></div>
                    </div>
                  </div>

                  {/* Desktop Preview */}
                  <div className="lg:col-span-8">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-[10px] font-black uppercase tracking-widest opacity-40">Expanded Result ({aspectRatio})</span>
                    </div>
                    <div className={cn(
                      "rounded-2xl overflow-hidden border border-[var(--border-color)] shadow-2xl relative bg-[var(--card-bg)] flex items-center justify-center transition-all duration-500",
                      aspectRatio === '16:9' ? "aspect-[16/9]" : 
                      aspectRatio === '21:9' ? "aspect-[21/9]" : "aspect-[32/9]"
                    )}>
                      {convertedImage ? (
                        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-full h-full relative group">
                           <img src={convertedImage} alt="Expanded" className="w-full h-full object-cover" />
                           <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                              <button onClick={() => downloadImage(convertedImage)} className="px-8 py-3 bg-white text-black font-bold rounded-full shadow-lg">Download Result</button>
                           </div>
                        </motion.div>
                      ) : (
                        <div className="flex flex-col items-center gap-4">
                           {isProcessing ? (
                             <>
                               <Loader2 className="w-10 h-10 animate-spin text-[var(--accent)]" />
                               <span className="text-xs font-bold uppercase tracking-widest animate-pulse opacity-50">Expanding Horizon...</span>
                             </>
                           ) : (
                             <Monitor className="w-12 h-12 opacity-10" />
                           )}
                        </div>
                      )}
                    </div>
                  </div>
               </div>

               {/* Controls */}
               <div className="lg:col-span-4 space-y-8">
                  <div className="p-8 rounded-3xl border border-[var(--border-color)] bg-[var(--card-bg)] shadow-sm">
                    <h4 className="font-bold mb-6 flex items-center gap-2"><Sparkles className="w-4 h-4 text-[var(--accent)]" /> Controls</h4>
                    
                    <div className="space-y-6">
                      <div>
                        <label className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 block mb-3">Aspect Ratio</label>
                        <div className="grid grid-cols-3 gap-2">
                           {(['16:9', '21:9', '32:9'] as AspectRatio[]).map(ratio => (
                             <button 
                                key={ratio}
                                onClick={() => setAspectRatio(ratio)}
                                className={cn(
                                  "py-2.5 rounded-xl text-xs font-bold border transition-all",
                                  aspectRatio === ratio ? "bg-[var(--text-primary)] text-[var(--bg-primary)] border-[var(--text-primary)]" : "bg-transparent border-[var(--border-color)] opacity-50"
                                )}
                             >
                               {ratio}
                             </button>
                           ))}
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 block mb-3">Resolution Output</label>
                        <div className="grid grid-cols-3 gap-2">
                           {(['4K', '8K', '16K'] as Resolution[]).map(res => (
                             <button 
                                key={res}
                                onClick={() => setResolution(res)}
                                className={cn(
                                  "py-2.5 rounded-xl text-xs font-bold border transition-all",
                                  resolution === res ? "bg-[var(--text-primary)] text-[var(--bg-primary)] border-[var(--text-primary)]" : "bg-transparent border-[var(--border-color)] opacity-50"
                                )}
                             >
                               {res}
                             </button>
                           ))}
                        </div>
                      </div>

                      {!convertedImage ? (
                        <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 block">Visual Prompt</label>
                          <textarea 
                            value={userPrompt}
                            onChange={(e) => setUserPrompt(e.target.value)}
                            placeholder="Describe expansion details..."
                            className="w-full h-24 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-xl p-4 text-sm focus:outline-none focus:ring-1 focus:ring-[var(--accent)]"
                          />
                          <button 
                            disabled={isProcessing}
                            onClick={handleConvert}
                            className="w-full py-4 bg-[var(--accent)] text-white rounded-xl font-bold hover:shadow-lg hover:shadow-[var(--accent)]/20 transition-all disabled:opacity-50"
                          >
                            Execute Expansion
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <label className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 block">Post-Generation Tweak</label>
                          <input 
                            value={postPrompt}
                            onChange={(e) => setPostPrompt(e.target.value)}
                            placeholder="Modify the result..."
                            className="w-full h-12 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-xl px-4 text-sm focus:outline-none focus:ring-1 focus:ring-[var(--accent)]"
                          />
                          <button 
                            disabled={isProcessing || !postPrompt}
                            onClick={handleRefine}
                            className="w-full py-4 border border-[var(--accent)] text-[var(--accent)] rounded-xl font-bold hover:bg-[var(--accent)]/5 transition-all disabled:opacity-50"
                          >
                            Refine Image
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {error && (
                    <div className="p-4 rounded-xl bg-red-500/5 border border-red-500/20 text-red-500 text-xs text-center font-medium">
                      {error}
                    </div>
                  )}
               </div>
            </div>
          )}
        </section>
      </main>

      <footer className="py-12 border-t border-[var(--border-color)] text-center">
         <p className="text-[10px] font-bold uppercase tracking-[0.3em] opacity-30">VisionShift 4K • Studio Grade AI Expansion</p>
      </footer>
    </div>
  );
}

function ThemeToggle({ theme, setTheme }: { theme: Theme, setTheme: (t: Theme) => void }) {
  const modes: { id: Theme, icon: React.ReactNode }[] = [
    { id: 'dark', icon: <Moon className="w-4 h-4" /> },
    { id: 'light', icon: <Sun className="w-4 h-4" /> },
    { id: 'cream', icon: <Palette className="w-4 h-4" /> }
  ];

  return (
    <div className="p-1 rounded-xl bg-[var(--card-bg)] border border-[var(--border-color)] flex gap-1">
      {modes.map((mode) => (
        <button
          key={mode.id}
          onClick={() => setTheme(mode.id)}
          className={cn(
            "p-2 rounded-lg transition-all",
            theme === mode.id ? "bg-[var(--bg-primary)] shadow-sm text-[var(--accent)]" : "opacity-40 hover:opacity-100"
          )}
        >
          {mode.icon}
        </button>
      ))}
    </div>
  );
}

function MenuSection({ title, icon, children }: { title: string, icon: React.ReactNode, children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-4">
        {icon}
        <span className="text-[10px] font-black uppercase tracking-widest opacity-40">{title}</span>
      </div>
      <div>{children}</div>
    </div>
  );
}
