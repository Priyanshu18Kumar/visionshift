/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  Image as ImageIcon, 
  Monitor, 
  Download, 
  Loader2, 
  Smartphone, 
  ArrowRight,
  Sparkles,
  RefreshCw,
  X
} from 'lucide-react';
import { convertMobileToDesktop, refineWallpaper, type Resolution } from './services/visionService';
import { cn } from './lib/utils';

export default function App() {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [convertedImage, setConvertedImage] = useState<string | null>(null);
  const [userPrompt, setUserPrompt] = useState("");
  const [postPrompt, setPostPrompt] = useState("");
  const [resolution, setResolution] = useState<Resolution>('4K');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError("Please upload an image file.");
      return;
    }
    setError(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      setOriginalImage(e.target?.result as string);
      setConvertedImage(null);
      setPostPrompt("");
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleConvert = async () => {
    if (!originalImage) return;

    setIsProcessing(true);
    setError(null);

    try {
      const [typePart, dataPart] = originalImage.split(',');
      const mimeType = typePart.split(':')[1].split(';')[0];
      
      const result = await convertMobileToDesktop(dataPart, mimeType, userPrompt, resolution);
      setConvertedImage(result);
    } catch (err: any) {
      console.error(err);
      handleError(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRefine = async () => {
    if (!convertedImage || !postPrompt) return;

    setIsProcessing(true);
    setError(null);

    try {
      const [typePart, dataPart] = convertedImage.split(',');
      const mimeType = typePart.split(':')[1].split(';')[0];
      
      const result = await refineWallpaper(dataPart, mimeType, postPrompt);
      setConvertedImage(result);
      setPostPrompt("");
    } catch (err: any) {
      console.error(err);
      handleError(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleError = (err: any) => {
    let message = err.message || "An error occurred.";
    if (message.includes("403") || message.includes("PERMISSION_DENIED")) {
      message = "Permission Denied: This model might be restricted. Switching to a standard model (Gemini 2.5).";
    } else if (message.includes("429") || message.includes("RESOURCE_EXHAUSTED")) {
      message = "Quota Exceeded: Too many requests. Please try again later.";
    }
    setError(message);
  };

  const reset = () => {
    setOriginalImage(null);
    setConvertedImage(null);
    setError(null);
  };

  const downloadImage = () => {
    if (!convertedImage) return;
    const link = document.createElement('a');
    link.href = convertedImage;
    link.download = 'visionshift-4k-wallpaper.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white font-sans selection:bg-orange-500/30">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-orange-600/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[120px]" />
      </div>

      <main className="relative z-10 max-w-7xl mx-auto px-6 py-12 lg:py-24 flex flex-col items-center">
        {/* Header Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 backdrop-blur-md mb-6">
            <Sparkles className="w-4 h-4 text-orange-400" />
            <span className="text-[10px] uppercase tracking-widest font-semibold text-white/70">Powered by Gemini 3.1 4K</span>
          </div>
          <h1 className="text-6xl lg:text-8xl font-black tracking-tighter mb-4 bg-gradient-to-b from-white to-white/50 bg-clip-text text-transparent">
            VISIONSHIFT <span className="text-orange-500 italic">4K</span>
          </h1>
          <p className="text-white/60 text-lg lg:text-xl max-w-2xl mx-auto font-light">
            Transform your vertical mobile shots into cinematic 16:9 desktop wallpapers. 
            Intelligent AI expansion for true 4K resolution.
          </p>
        </motion.div>

        {/* Action Section */}
        <div className="w-full flex flex-col items-center gap-12">
          <AnimatePresence mode="wait">
            {!originalImage ? (
              <motion.div
                key="upload"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full max-w-4xl"
              >
                <div 
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className="group relative h-[400px] border-2 border-dashed border-white/10 rounded-3xl bg-white/[0.02] flex flex-col items-center justify-center cursor-pointer transition-all hover:bg-white/[0.04] hover:border-orange-500/50"
                  id="drop-zone"
                >
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handleFileChange} 
                  />
                  <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <Upload className="w-8 h-8 text-white/50 group-hover:text-white" />
                  </div>
                  <h3 className="text-2xl font-medium mb-2">Drop your 4K portrait here</h3>
                  <p className="text-white/40 font-light">HEIC, JPEG, or PNG (up to 4K resolution)</p>
                  
                  {/* Decorative corners */}
                  <div className="absolute top-6 left-6 w-4 h-4 border-t-2 border-l-2 border-white/20 group-hover:border-orange-500/50 transition-colors" />
                  <div className="absolute top-6 right-6 w-4 h-4 border-t-2 border-r-2 border-white/20 group-hover:border-orange-500/50 transition-colors" />
                  <div className="absolute bottom-6 left-6 w-4 h-4 border-b-2 border-l-2 border-white/20 group-hover:border-orange-500/50 transition-colors" />
                  <div className="absolute bottom-6 right-6 w-4 h-4 border-b-2 border-r-2 border-white/20 group-hover:border-orange-500/50 transition-colors" />
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="preview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="w-full max-w-6xl flex flex-col lg:flex-row items-stretch gap-8"
              >
                {/* Original Mobile Preview */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-4 px-2">
                    <div className="flex items-center gap-2 text-white/50 text-xs tracking-widest uppercase">
                      <Smartphone className="w-4 h-4" /> Original Mobile
                    </div>
                    {!isProcessing && (
                      <button onClick={reset} className="p-2 rounded-full hover:bg-white/10 transition-colors">
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  <div className="aspect-[9/16] bg-black rounded-2xl overflow-hidden border border-white/10 relative shadow-2xl shadow-black/50">
                    <img 
                      src={originalImage} 
                      alt="Original" 
                      className="w-full h-full object-cover" 
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>

                {/* Transition Arrow */}
                <div className="flex flex-col items-center justify-center lg:px-4">
                  <motion.div 
                    animate={isProcessing ? { scale: [1, 1.2, 1], rotate: 360 } : {}}
                    transition={isProcessing ? { duration: 2, repeat: Infinity } : {}}
                    className="w-12 h-12 rounded-full bg-orange-500 flex items-center justify-center shadow-lg shadow-orange-500/20"
                  >
                    <ArrowRight className="w-6 h-6 text-black" />
                  </motion.div>
                </div>

                {/* Converted Desktop Preview */}
                <div className="flex-[2] min-w-0">
                  <div className="flex items-center justify-between mb-4 px-2">
                    <div className="flex items-center gap-2 text-white/50 text-xs tracking-widest uppercase">
                      <Monitor className="w-4 h-4" /> Desktop Wallpaper 16:9
                    </div>
                  </div>
                  <div className="aspect-[16/9] bg-black/50 border border-white/10 rounded-2xl overflow-hidden relative shadow-2xl shadow-black/50 group">
                    {convertedImage ? (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-full">
                        <img 
                          src={convertedImage} 
                          alt="Converted" 
                          className="w-full h-full object-cover" 
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                          <button 
                            onClick={downloadImage}
                            className="flex items-center gap-3 px-8 py-4 bg-white text-black rounded-full font-bold hover:scale-105 active:scale-95 transition-all"
                          >
                            <Download className="w-5 h-5" /> Download 4K
                          </button>
                        </div>
                      </motion.div>
                    ) : (
                      <div className="h-full flex flex-col items-center justify-center text-white/30">
                        {isProcessing ? (
                          <div className="flex flex-col items-center gap-4">
                            <Loader2 className="w-12 h-12 animate-spin text-orange-500" />
                            <p className="text-orange-500 font-medium tracking-tight animate-pulse">Intelligently expanding scene...</p>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center gap-6 w-full px-12">
                            {/* Resolution Switcher */}
                            <div className="w-full space-y-3">
                              <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold ml-1 text-center block">Target Quality</label>
                              <div className="flex gap-2 justify-center">
                                {(['4K', '8K', '16K'] as Resolution[]).map((res) => (
                                  <button
                                    key={res}
                                    onClick={() => setResolution(res)}
                                    className={cn(
                                      "px-4 py-2 rounded-lg text-xs font-bold transition-all border",
                                      resolution === res 
                                        ? "bg-white text-black border-white" 
                                        : "bg-white/5 text-white/50 border-white/10 hover:bg-white/10"
                                    )}
                                  >
                                    {res}
                                  </button>
                                ))}
                              </div>
                            </div>

                            <div className="w-full space-y-3">
                              <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold ml-1">Creative Direction (Optional)</label>
                              <div className="relative group/input">
                                <textarea 
                                  value={userPrompt}
                                  onChange={(e) => setUserPrompt(e.target.value)}
                                  placeholder="e.g. 'Add a dramatic sunset', 'Cyberpunk city vibes', 'Lush tropical island...'"
                                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-orange-500/50 transition-all resize-none h-24"
                                />
                                <div className="absolute top-3 right-3">
                                  <Sparkles className="w-4 h-4 text-white/20 group-focus-within/input:text-orange-400 transition-colors" />
                                </div>
                              </div>
                            </div>
                            <button 
                              onClick={handleConvert}
                              className="w-full max-w-xs px-8 py-4 bg-orange-500 text-black rounded-full font-bold hover:bg-orange-400 transition-colors shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2"
                            >
                              Generate Wallpaper
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Post-Prompt Refinement Section */}
                  <AnimatePresence>
                    {convertedImage && !isProcessing && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mt-6 p-6 rounded-2xl bg-white/[0.03] border border-white/10"
                      >
                        <h5 className="text-sm font-medium mb-4 flex items-center gap-2">
                          <RefreshCw className="w-4 h-4 text-orange-400" /> Further Refining
                        </h5>
                        <div className="flex gap-4">
                          <input 
                            type="text"
                            value={postPrompt}
                            onChange={(e) => setPostPrompt(e.target.value)}
                            placeholder="Type any changes you want... (e.g., 'make the sky more blue')"
                            className="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-orange-500/50 transition-all"
                            onKeyDown={(e) => e.key === 'Enter' && handleRefine()}
                          />
                          <button 
                            onClick={handleRefine}
                            disabled={!postPrompt}
                            className="px-6 py-2 bg-white text-black rounded-xl font-bold text-sm hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            Iterate
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer / Error */}
        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="mt-8 px-6 py-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 text-sm"
            >
              {error}
            </motion.div>
          )}
        </AnimatePresence>

        <section className="mt-32 w-full grid grid-cols-1 md:grid-cols-3 gap-8">
          <FeatureCard 
            icon={<Sparkles className="w-6 h-6 text-orange-400" />}
            title="Gen-AI Expansion"
            description="Our model doesn't just crop. It builds out the sides of your photo using advanced scene understanding."
          />
          <FeatureCard 
            icon={<Monitor className="w-6 h-6 text-blue-400" />}
            title="True 16:9 Aspect"
            description="Perfectly proportioned for modern monitors, from standard HD up to vibrant 4K displays."
          />
          <FeatureCard 
            icon={<RefreshCw className="w-6 h-6 text-emerald-400" />}
            title="Style Preservation"
            description="Maintains color grading, lighting, and textures to ensure the expansion feels part of the original."
          />
        </section>
      </main>

      <footer className="relative z-10 border-t border-white/5 mt-24 py-12 text-center text-white/30 text-xs tracking-[0.2em] font-light uppercase">
        © VisionShift 4K • Powered by Antigravity
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="p-8 rounded-3xl border border-white/5 bg-white/[0.01] hover:bg-white/[0.02] transition-colors">
      <div className="mb-6">{icon}</div>
      <h4 className="text-lg font-medium mb-3">{title}</h4>
      <p className="text-white/40 font-light text-sm leading-relaxed">{description}</p>
    </div>
  );
}
